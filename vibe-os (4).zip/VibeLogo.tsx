import React from 'react';

export const VibeLogo = () => (
  <svg viewBox="0 0 240 80" className="h-10 md:h-12 w-auto filter drop-shadow-[0_0_15px_rgba(6,182,212,0.4)]" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path 
      d="M0 40 H 20 L 35 65 L 55 15 L 70 40 H 240" 
      stroke="url(#pulse-gradient)" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round"
      className="animate-[shimmer_3s_infinite]"
    />
    <text 
      x="80" 
      y="52" 
      fontFamily="Rajdhani" 
      fontWeight="700" 
      fontSize="48" 
      letterSpacing="0.1em" 
      fill="white"
      className="drop-shadow-[0_0_10px_rgba(255,255,255,0.5)]"
    >
      VIBE
    </text>
    <path 
      d="M 35 65 L 55 15" 
      stroke="white" 
      strokeWidth="3" 
      strokeLinecap="round"
      className="animate-pulse-glow"
    />
    <defs>
      <linearGradient id="pulse-gradient" x1="0" y1="0" x2="240" y2="0" gradientUnits="userSpaceOnUse">
        <stop stopColor="rgba(255,255,255,0)" />
        <stop offset="0.1" stopColor="#06b6d4" />
        <stop offset="0.3" stopColor="#ffffff" />
        <stop offset="0.5" stopColor="#06b6d4" />
        <stop offset="1" stopColor="rgba(255,255,255,0)" />
      </linearGradient>
    </defs>
  </svg>
);