import { 
  MessageCircle, 
  Activity, 
  ShieldCheck, 
  Zap, 
  Wifi, 
  Lock 
} from 'lucide-react';
import { ModuleData, SecurityLevel } from './types';

export const CORE_MODULES: ModuleData[] = [
  {
    id: 'discord-uplink',
    title: 'DISCORD SERVER',
    category: 'CORE',
    level: SecurityLevel.STANDARD,
    stats: [
      { label: 'Members', value: '42.8k' },
      { label: 'Online', value: '3,402' }
    ],
    icon: MessageCircle,
    colorTheme: 'violet',
    description: 'Establish encrypted voice and text comms with the Vibe community operatives.',
    actionUrl: 'https://discord.gg/xYAB2FYx8Z'
  },
  {
    id: 'injuries-log',
    title: 'INJURIES',
    category: 'NETWORK',
    level: SecurityLevel.CRITICAL,
    stats: [
      { label: 'Status', value: 'Active' },
      { label: 'Bypass', value: 'Ready' }
    ],
    icon: Activity,
    colorTheme: 'amber',
    description: [
      'Auto Secure',
      'Fast Login',
      'Auto Auth',
      'Age <13'
    ],
    actionUrl: 'https://www.logged.tg/auth/unknowngu'
  },
  {
    id: 'immortal-core',
    title: 'IMMORTAL',
    category: 'CORE',
    level: SecurityLevel.RESTRICTED,
    stats: [],
    icon: ShieldCheck,
    colorTheme: 'violet',
    description: [
      'Best Generator for Backup',
      'Auto Secure',
      'Auto Recovery Codes',
      'Auto > 13',
      'Auto Authenticator'
    ],
    actionUrl: 'https://immortal.rs/?code=MDgzNDI0NjEyMjcyMjM5NTI4N18wNjA0MjI1MTQ4MjMxMzY0MTE2Xzg4MzIwNTUxOTk0NDExMTQzODI='
  },
  {
    id: 'shockify',
    title: 'SHOCKIFY',
    category: 'CORE',
    level: SecurityLevel.CRITICAL,
    stats: [],
    icon: Zap,
    colorTheme: 'rose',
    description: [
      'Same Features with Immortal',
      'Auto Secure',
      'Not Recommended',
      'Always Ready'
    ],
    actionUrl: 'https://shockify.st/?code=MjE2MzM3OTExNzQ2MjI5NzI0M184ODMyMDU1MTk5NDQxMTE0Mzgy'
  }
];

export const UTILITY_MODULES: ModuleData[] = [
  {
    id: 'proxy-tunnel',
    title: 'HYPERLINK',
    category: 'UTILITY',
    level: SecurityLevel.ELEVATED,
    stats: [],
    icon: Wifi,
    colorTheme: 'cyan',
    description: [
      'Hide Link',
      'Useful When Your Beaming',
      'Ultra Stealth'
    ],
    actionUrl: 'https://insanityhyperlink.netlify.app/'
  },
  {
    id: 'session-intercept',
    title: 'COOKIE BYPASSER',
    category: 'UTILITY',
    level: SecurityLevel.RESTRICTED,
    stats: [],
    icon: Lock,
    colorTheme: 'violet',
    description: [
      'Bypass 2 step verification',
      'Email Remover',
      'I don\'t know if it\'s legit'
    ],
    actionUrl: 'https://roblox-age-bypasser.vercel.app/'
  }
];