import { LucideIcon } from 'lucide-react';

export enum SecurityLevel {
  STANDARD = 'STANDARD',
  ELEVATED = 'ELEVATED',
  RESTRICTED = 'RESTRICTED',
  CRITICAL = 'CRITICAL'
}

export interface ModuleData {
  id: string;
  title: string;
  category: 'CORE' | 'UTILITY' | 'NETWORK';
  level: SecurityLevel;
  stats: { label: string; value: string }[];
  icon: LucideIcon;
  colorTheme: 'cyan' | 'violet' | 'rose' | 'amber';
  description: string | string[];
  actionUrl?: string;
}