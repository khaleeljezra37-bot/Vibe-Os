import React, { useState } from 'react';
import { Cpu, Layers } from 'lucide-react';
import { CORE_MODULES, UTILITY_MODULES } from './constants';
import { ModuleData } from './types';
import ModuleCard from './components/PixelCard';
import SystemModal from './components/OracleModal';
import { WelcomeScreen } from './components/WelcomeScreen';
import { VibeLogo } from './components/VibeLogo';
import CustomCursor from './components/CustomCursor';
import { BootSequence } from './components/BootSequence';

export default function App() {
  const [booted, setBooted] = useState(false);
  const [started, setStarted] = useState(false);
  const [selected, setSelected] = useState<ModuleData | null>(null);

  if (!booted) return (
    <>
      <CustomCursor />
      <BootSequence onComplete={() => setBooted(true)} />
    </>
  );

  if (!started) return (
    <>
      <CustomCursor />
      <WelcomeScreen onStart={() => setStarted(true)} />
    </>
  );

  return (
    <div className="min-h-screen text-white relative selection:bg-cyan-500/30 selection:text-cyan-100 cursor-none overflow-x-hidden">
      <CustomCursor />
      
      {/* Background Ambience */}
      <div className="fixed inset-0 z-[-1] pointer-events-none">
         <div className="absolute top-[-50%] left-[-50%] w-[200%] h-[200%] bg-[radial-gradient(circle_at_center,rgba(6,182,212,0.03),transparent_40%)] animate-[spin_60s_linear_infinite]"></div>
      </div>
      
      {/* Navbar */}
      <nav className="fixed top-0 w-full z-40 bg-black/60 backdrop-blur-md border-b border-white/5 px-6 py-4 flex justify-between items-center transition-all duration-500 hover:bg-black/80">
         <div className="flex items-center gap-2 cursor-pointer opacity-80 hover:opacity-100 transition-opacity" onClick={() => window.location.reload()}>
           <VibeLogo />
         </div>
         <div className="hidden md:flex gap-8 text-[10px] font-bold tracking-[0.2em] text-gray-500 font-mono-tech">
           <div className="flex items-center gap-2">
             <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
             </span>
             <span className="text-green-500 text-shadow-green">SYSTEM ONLINE</span>
           </div>
           <span className="hover:text-cyan-400 transition-colors cursor-default">NET: ENCRYPTED</span>
           <span className="hover:text-cyan-400 transition-colors cursor-default">V.4.2.0-STABLE</span>
         </div>
      </nav>

      {/* Main Content */}
      <main className="pt-32 pb-24 max-w-[1600px] mx-auto px-6 md:px-12">
        <div className="mb-20 animate-[springUp_1s_ease-out]">
           <h1 className="text-5xl md:text-8xl font-bold font-tech mb-6 text-white tracking-tighter drop-shadow-[0_0_30px_rgba(255,255,255,0.2)] cursor-default mix-blend-screen">
             COMMAND <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-500">CENTER</span>
           </h1>
           <p className="text-gray-400 font-mono-tech text-sm md:text-base max-w-2xl border-l-2 border-cyan-500 pl-6 py-2 bg-gradient-to-r from-cyan-900/10 to-transparent cursor-default">
             // WELCOME OPERATIVE.<br/>
             // SELECT A MODULE TO INITIALIZE PROTOCOLS.
           </p>
        </div>

        <div className="space-y-24">
           {/* Core Modules Section */}
           <section>
              <div className="flex items-center gap-4 mb-8 group cursor-default">
                 <div className="p-2 rounded bg-cyan-900/10 border border-cyan-500/30 group-hover:bg-cyan-500/20 transition-colors">
                    <Cpu className="text-cyan-400 w-5 h-5" />
                 </div>
                 <h2 className="text-xl font-bold font-tech tracking-[0.2em] text-gray-300 group-hover:text-cyan-400 transition-colors">CORE_SYSTEMS</h2>
                 <div className="h-px bg-gradient-to-r from-cyan-500/50 to-transparent flex-1 ml-6" />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                 {CORE_MODULES.map((m, i) => (
                    <ModuleCard key={m.id} data={m} index={i} onSelect={setSelected} />
                 ))}
              </div>
           </section>

           {/* Utility Modules Section */}
           <section>
              <div className="flex items-center gap-4 mb-8 group cursor-default">
                 <div className="p-2 rounded bg-violet-900/10 border border-violet-500/30 group-hover:bg-violet-500/20 transition-colors">
                    <Layers className="text-violet-400 w-5 h-5" />
                 </div>
                 <h2 className="text-xl font-bold font-tech tracking-[0.2em] text-gray-300 group-hover:text-violet-400 transition-colors">NET_UTILITIES</h2>
                 <div className="h-px bg-gradient-to-r from-violet-500/50 to-transparent flex-1 ml-6" />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                 {UTILITY_MODULES.map((m, i) => (
                    <ModuleCard key={m.id} data={m} index={i + 4} onSelect={setSelected} />
                 ))}
              </div>
           </section>
        </div>
      </main>

      {/* Footer */}
      <footer className="fixed bottom-0 w-full bg-black/80 backdrop-blur-xl border-t border-white/5 py-2 px-8 flex justify-between items-center text-[9px] text-gray-600 font-mono-tech uppercase z-30 cursor-default">
         <span className="flex items-center gap-2">
            <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></div>
            SECURE CONNECTION ESTABLISHED
         </span>
         <span>SESSION ID: {Math.random().toString(36).substr(2, 9).toUpperCase()}</span>
      </footer>

      <SystemModal quest={selected} onClose={() => setSelected(null)} />
    </div>
  );
}