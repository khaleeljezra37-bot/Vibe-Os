import React from 'react';
import { Fingerprint, Info } from 'lucide-react';
import { VibeLogo } from './VibeLogo';

export const WelcomeScreen = ({ onStart }: { onStart: () => void }) => {
  return (
    <div className="fixed inset-0 z-[100] flex flex-col items-center justify-center overflow-hidden h-[100dvh]">
       <div className="absolute inset-0 bg-black/60 backdrop-blur-sm z-0"></div>
       
       <div className="relative z-10 flex flex-col items-center gap-8 md:gap-12 animate-unfold p-6 w-full max-w-2xl mx-auto">
          
          <div className="relative group cursor-default">
             <div className="absolute -inset-10 bg-cyan-500/20 rounded-full blur-3xl opacity-20 group-hover:opacity-40 transition-opacity duration-1000"></div>
             <div className="transform scale-125 md:scale-150 drop-shadow-[0_0_20px_rgba(6,182,212,0.3)]">
                <VibeLogo />
             </div>
          </div>

          <div className="flex flex-col items-center gap-2 text-center w-full">
             <div className="flex flex-col items-center leading-none tracking-widest uppercase">
                <span className="glitch font-tech text-5xl md:text-7xl font-bold text-white mb-2" data-text="SYSTEM">SYSTEM</span>
                <span className="glitch font-tech text-5xl md:text-7xl font-bold text-cyan-400 drop-shadow-[0_0_15px_rgba(6,182,212,0.8)]" data-text="LOCKED">LOCKED</span>
             </div>
             
             <div className="mt-6 flex items-center gap-3 w-full max-w-xs">
                <div className="h-px bg-gradient-to-r from-transparent via-cyan-500/50 to-transparent flex-1"></div>
                <p className="font-mono text-[10px] text-cyan-500/80 tracking-[0.2em] md:tracking-[0.3em] uppercase whitespace-nowrap">
                   Secure Gateway Access
                </p>
                <div className="h-px bg-gradient-to-r from-transparent via-cyan-500/50 to-transparent flex-1"></div>
             </div>
          </div>

          <button
            onClick={onStart}
            className="group relative px-10 py-5 md:px-16 md:py-6 bg-black/40 border border-white/10 hover:border-cyan-500/80 transition-all duration-500 rounded-sm overflow-visible mt-4 hover:shadow-[0_0_50px_rgba(6,182,212,0.2)] active:scale-95"
          >
             {/* Idle Glow */}
             <div className="absolute inset-0 shadow-[0_0_20px_rgba(6,182,212,0.1)] animate-pulse-slow"></div>

             {/* Background Pulse/Shimmer */}
             <div className="absolute inset-0 bg-gradient-to-r from-transparent via-cyan-500/10 to-transparent -translate-x-full group-hover:animate-[shimmer_1.5s_infinite] overflow-hidden"></div>
             
             <div className="absolute top-0 left-0 w-full h-[2px] bg-cyan-400/80 shadow-[0_0_15px_rgba(6,182,212,1)] opacity-0 group-hover:animate-[scan-vertical_1.5s_linear_infinite]"></div>

             <div className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-white/30 group-hover:border-cyan-400 transition-all duration-300 group-hover:-translate-x-2 group-hover:-translate-y-2"></div>
             <div className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-white/30 group-hover:border-cyan-400 transition-all duration-300 group-hover:translate-x-2 group-hover:-translate-y-2"></div>
             <div className="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-white/30 group-hover:border-cyan-400 transition-all duration-300 group-hover:-translate-x-2 group-hover:translate-y-2"></div>
             <div className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-white/30 group-hover:border-cyan-400 transition-all duration-300 group-hover:translate-x-2 group-hover:translate-y-2"></div>
             
             <span className="relative z-10 font-mono text-lg md:text-xl tracking-[0.2em] md:tracking-[0.3em] text-gray-300 group-hover:text-cyan-50 transition-colors flex items-center gap-3 md:gap-5 group-hover:drop-shadow-[0_0_8px_rgba(6,182,212,0.8)]">
                <Fingerprint className="w-5 h-5 md:w-6 md:h-6 group-hover:animate-pulse text-cyan-600 group-hover:text-cyan-400" />
                AUTHENTICATE
             </span>
          </button>

          <div className="mt-2 text-center animate-unfold" style={{ animationDelay: '300ms' }}>
             <div className="inline-flex items-center gap-3 px-6 py-3 rounded-full bg-white/5 border border-white/5 hover:bg-white/10 hover:border-cyan-500/30 transition-all duration-300 backdrop-blur-sm group cursor-pointer">
                <Info className="w-4 h-4 text-cyan-500/70 group-hover:text-cyan-400 transition-colors" />
                <p className="font-mono text-[10px] md:text-xs text-gray-500 tracking-wider uppercase">
                   <span className="hidden md:inline">HAVING TROUBLE? </span>
                   <a 
                     href="https://discord.gg/xYAB2FYx8Z" 
                     target="_blank" 
                     rel="noopener noreferrer"
                     className="text-gray-300 group-hover:text-cyan-400 transition-colors font-bold ml-1"
                   >
                     SUPPORT
                   </a>
                </p>
             </div>
          </div>
       </div>
    </div>
  );
};