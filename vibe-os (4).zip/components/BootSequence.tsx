import React, { useEffect, useState } from 'react';

const BOOT_LINES = [
  "VIBE_BIOS (C) 2077 // V.4.2.0",
  "Checking Memory................... 64TB OK",
  "Loading Kernel Modules............ OK",
  "Initializing GPU Clusters......... OK",
  "Mounting File System.............. OK",
  "Establishing Secure Connection.... ENCRYPTED",
  "Bypassing Regional Firewalls...... DONE",
  "Loading Vibe OS Interface........."
];

export const BootSequence: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  const [lines, setLines] = useState<string[]>([]);
  
  useEffect(() => {
    let delay = 0;
    BOOT_LINES.forEach((line, index) => {
      // Slightly faster sequence
      delay += 100 + Math.random() * 200;
      setTimeout(() => {
        setLines(prev => [...prev, line]);
        
        // Play simple beep
        const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
        if (AudioContext) {
           try {
             const ctx = new AudioContext();
             const osc = ctx.createOscillator();
             const gain = ctx.createGain();
             osc.frequency.value = 400 + (Math.random() * 200);
             osc.type = 'square';
             gain.gain.value = 0.05;
             osc.connect(gain);
             gain.connect(ctx.destination);
             osc.start();
             osc.stop(ctx.currentTime + 0.05);
           } catch(e) { /* ignore */ }
        }
        
      }, delay);
    });

    setTimeout(onComplete, delay + 800);
  }, [onComplete]);

  return (
    <div className="fixed inset-0 z-[200] bg-black font-mono text-xs md:text-sm p-8 md:p-12 text-cyan-500 overflow-hidden cursor-none flex flex-col justify-between">
       <div className="max-w-3xl mx-auto space-y-1 w-full">
          {lines.map((line, i) => (
             <div key={i} className="animate-[slideRight_0.1s_ease-out]">
                <span className="text-gray-600 mr-2">[{new Date().toLocaleTimeString()}]</span>
                <span className="drop-shadow-[0_0_5px_rgba(6,182,212,0.8)]">{line}</span>
             </div>
          ))}
          <div className="animate-pulse mt-4">_</div>
       </div>
       
       <div className="text-gray-700 text-[10px] w-full flex justify-between uppercase">
          <span>VIBE SYSTEM</span>
          <span>MEMORY CHECK: OK | CPU: 12% | TEMP: 42°C</span>
       </div>
    </div>
  );
};