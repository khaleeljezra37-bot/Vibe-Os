import React from 'react';

export const VibeLogo = () => (
  <svg viewBox="0 0 240 80" className="h-10 md:h-12 w-auto filter drop-shadow-[0_0_10px_rgba(6,182,212,0.6)]" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M0 40 H 20 L 35 65 L 55 15 L 70 40 H 240" stroke="cyan" strokeWidth="2" strokeLinecap="round" className="animate-pulse" />
    <text x="80" y="52" fontFamily="Rajdhani" fontWeight="700" fontSize="48" letterSpacing="0.1em" fill="white">VIBE</text>
  </svg>
);