import React from 'react';
import { Fingerprint, Info, ShieldCheck } from 'lucide-react';
import { VibeLogo } from './VibeLogo';

export const WelcomeScreen = ({ onStart }: { onStart: () => void }) => {
  return (
    <div className="fixed inset-0 z-[100] flex flex-col items-center justify-center overflow-hidden h-screen w-screen bg-black">
       {/* Background layers */}
       <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(6,182,212,0.1),transparent_70%)] animate-pulse-slow"></div>
       <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-10"></div>
       
       <div className="relative z-10 flex flex-col items-center gap-12 animate-[unfold_0.8s_ease-out] w-full max-w-4xl p-8">
          
          {/* Logo Container */}
          <div className="relative group cursor-default hover:scale-105 transition-transform duration-700">
             <div className="absolute -inset-20 bg-cyan-500/20 rounded-full blur-[100px] opacity-20 group-hover:opacity-40 transition-opacity duration-1000"></div>
             <div className="transform scale-150 drop-shadow-[0_0_30px_rgba(6,182,212,0.4)]">
                <VibeLogo />
             </div>
          </div>

          {/* Main Title Block */}
          <div className="flex flex-col items-center text-center w-full space-y-8">
             <div className="flex flex-col items-center leading-none tracking-[0.1em] uppercase select-none">
                <span className="font-tech text-8xl font-black text-white mb-2 tracking-tighter mix-blend-difference">SYSTEM</span>
                <div className="relative">
                  <span className="absolute -inset-1 text-red-500 opacity-50 blur-[1px] animate-[pulse_0.2s_infinite]">LOCKED</span>
                  <span className="font-tech text-8xl font-black text-cyan-400 drop-shadow-[0_0_25px_rgba(6,182,212,0.8)] tracking-tighter">LOCKED</span>
                </div>
             </div>
             
             <div className="flex items-center gap-4 w-full max-w-md opacity-80">
                <div className="h-px bg-gradient-to-r from-transparent via-cyan-500 to-transparent flex-1"></div>
                <div className="flex items-center gap-2 text-cyan-400 font-mono text-xs tracking-[0.3em] uppercase">
                   <ShieldCheck className="w-3 h-3" />
                   <span>Secure Gateway V.4.2</span>
                </div>
                <div className="h-px bg-gradient-to-r from-transparent via-cyan-500 to-transparent flex-1"></div>
             </div>
          </div>

          {/* Interaction Area */}
          <div className="flex flex-col items-center gap-6 mt-4">
            <button
              onClick={onStart}
              className="group relative px-20 py-6 bg-black border border-white/10 overflow-hidden transition-all duration-300 hover:border-cyan-500/50 hover:shadow-[0_0_60px_-10px_rgba(6,182,212,0.3)]"
            >
               {/* Hover Sweep Effect */}
               <div className="absolute inset-0 bg-gradient-to-r from-transparent via-cyan-900/40 to-transparent -translate-x-[200%] group-hover:translate-x-[200%] transition-transform duration-1000 ease-in-out"></div>
               
               {/* Corner Accents */}
               <div className="absolute top-0 left-0 w-2 h-2 border-t-2 border-l-2 border-white/30 group-hover:border-cyan-400 group-hover:w-4 group-hover:h-4 transition-all duration-300"></div>
               <div className="absolute top-0 right-0 w-2 h-2 border-t-2 border-r-2 border-white/30 group-hover:border-cyan-400 group-hover:w-4 group-hover:h-4 transition-all duration-300"></div>
               <div className="absolute bottom-0 left-0 w-2 h-2 border-b-2 border-l-2 border-white/30 group-hover:border-cyan-400 group-hover:w-4 group-hover:h-4 transition-all duration-300"></div>
               <div className="absolute bottom-0 right-0 w-2 h-2 border-b-2 border-r-2 border-white/30 group-hover:border-cyan-400 group-hover:w-4 group-hover:h-4 transition-all duration-300"></div>
               
               <span className="relative z-10 font-mono text-xl tracking-[0.25em] text-gray-400 group-hover:text-white transition-colors flex items-center gap-6">
                  <Fingerprint className="w-6 h-6 text-cyan-600 group-hover:text-cyan-400 group-hover:animate-pulse" />
                  INITIALIZE_SESSION
               </span>
            </button>

            <a 
              href="https://discord.gg/xYAB2FYx8Z" 
              target="_blank" 
              rel="noopener noreferrer"
              className="group flex items-center gap-2 text-[10px] uppercase tracking-widest text-gray-600 hover:text-cyan-400 transition-colors"
            >
              <Info className="w-3 h-3" />
              <span>Request Access / Support</span>
            </a>
          </div>
       </div>
    </div>
  );
};