import React, { useEffect, useState, useRef } from 'react';
import { ModuleData } from '../types';
import { X, ChevronRight, Terminal, Activity, ShieldAlert, Cpu } from 'lucide-react';
import { generateMissionBriefing } from '../services/geminiService';

interface SystemModalProps {
  quest: ModuleData | null;
  onClose: () => void;
}

const SystemModal: React.FC<SystemModalProps> = ({ quest, onClose }) => {
  const [log, setLog] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [streamedText, setStreamedText] = useState('');
  const [isReady, setIsReady] = useState(false);
  const textEndRef = useRef<HTMLDivElement>(null);

  // Sound effect helper
  const playSound = (freq: number, type: OscillatorType, duration: number) => {
    const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContext) return;
    try {
      const ctx = new AudioContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      gain.gain.setValueAtTime(0.05, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + duration);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + duration);
    } catch (e) {
      // Ignore audio errors
    }
  };

  useEffect(() => {
    if (quest) {
      playSound(800, 'sine', 0.1);
      setLoading(true);
      setLog('');
      setStreamedText('');
      setIsReady(false);
      
      const descText = Array.isArray(quest.description) 
        ? quest.description.join('. ') 
        : quest.description;
      
      generateMissionBriefing(quest.title, descText).then((text) => {
        setLog(text);
        setLoading(false);
      });
    }
  }, [quest]);

  // Smooth text streaming
  useEffect(() => {
    if (!loading && log) {
      let i = 0;
      const speed = 20; 
      const interval = setInterval(() => {
        setStreamedText(log.slice(0, i + 1));
        if (i % 3 === 0) playSound(1000 + (Math.random() * 200), 'square', 0.05); // Typing sound
        i++;
        if (i > log.length) {
          clearInterval(interval);
          setIsReady(true);
          playSound(1200, 'sine', 0.3); // Ready sound
        }
      }, speed);
      return () => clearInterval(interval);
    }
  }, [loading, log]);

  // Auto-scroll to bottom of text
  useEffect(() => {
    textEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [streamedText]);

  const handleExecute = () => {
    playSound(1500, 'square', 0.2);
    if (quest?.actionUrl) {
      window.open(quest.actionUrl, '_blank');
    }
    onClose();
  };

  if (!quest) return null;

  const ThemeIcon = quest.icon;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-8 bg-black/90 backdrop-blur-xl animate-[unfold_0.3s_ease-out] cursor-default font-mono">
      <div 
        className="relative w-full max-w-5xl bg-[#050505] border border-cyan-900/50 rounded-lg shadow-[0_0_100px_rgba(6,182,212,0.15)] overflow-hidden flex flex-col md:flex-row"
        style={{ boxShadow: `0 0 80px -20px rgba(6,182,212,0.2)` }}
      >
        
        {/* Left Sidebar - Visual */}
        <div className="w-full md:w-72 bg-black border-b md:border-b-0 md:border-r border-cyan-900/30 relative overflow-hidden flex flex-col items-center justify-center p-8 shrink-0">
            {/* Scanlines on sidebar */}
            <div className="absolute inset-0 bg-[linear-gradient(transparent_50%,rgba(6,182,212,0.05)_50%)] bg-[size:100%_4px]"></div>
            
            <div className="relative z-10 p-6 mb-6 group">
               <div className="absolute inset-0 bg-cyan-500/10 blur-xl rounded-full animate-pulse-slow"></div>
               <div className="relative border border-cyan-500/30 p-6 rounded-full bg-cyan-950/20">
                 <ThemeIcon className="w-12 h-12 text-cyan-400 drop-shadow-[0_0_10px_rgba(6,182,212,0.8)]" />
               </div>
            </div>
            
            <div className="relative z-10 text-center space-y-4">
                <h3 className="font-tech text-3xl font-bold text-white tracking-widest uppercase drop-shadow-[0_0_5px_rgba(255,255,255,0.5)]">{quest.title}</h3>
                <div className="flex flex-col gap-2">
                   <div className="flex items-center justify-center gap-2 text-xs text-cyan-600 border border-cyan-900/50 px-3 py-1 rounded bg-black">
                     <ShieldAlert className="w-3 h-3" />
                     <span>SEC: {quest.level}</span>
                   </div>
                </div>
            </div>
        </div>

        {/* Right Content - Terminal */}
        <div className="flex-1 flex flex-col min-h-[450px] relative bg-black/80">
           <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(circle_at_top_right,rgba(6,182,212,0.05),transparent_40%)]"></div>

           {/* Terminal Header */}
           <div className="flex items-center justify-between px-6 py-3 border-b border-cyan-900/30 bg-cyan-950/5">
             <div className="flex items-center gap-3">
               <Terminal className="w-4 h-4 text-cyan-500" />
               <span className="font-mono text-xs text-cyan-700">ROOT ACCESS // {quest.id.toUpperCase()}</span>
             </div>
             <button onClick={onClose} className="text-cyan-800 hover:text-red-500 transition-colors cursor-pointer hover:rotate-90 duration-300">
               <X className="w-5 h-5" />
             </button>
           </div>

           {/* Terminal Body */}
           <div className="flex-1 p-8 overflow-y-auto font-mono text-sm leading-relaxed scrollbar-hide">
              <div className="mb-6 space-y-1">
                 <div className="text-gray-500 text-xs">Target System Identified...</div>
                 <div className="text-gray-500 text-xs">Bypassing Firewalls... <span className="text-green-500">SUCCESS</span></div>
                 <div className="text-gray-500 text-xs">Establishing Uplink... <span className="text-green-500">CONNECTED</span></div>
              </div>

              <div className="border-l-2 border-cyan-800/50 pl-4 py-2 mb-4 bg-cyan-950/10">
                 <div className="text-cyan-300 mb-2 font-bold flex items-center gap-2">
                    <Cpu className="w-3 h-3" />
                    MISSION_BRIEFING
                 </div>
                 
                 {loading ? (
                   <div className="flex items-center gap-2 text-cyan-600 animate-pulse">
                      <Activity className="w-4 h-4" />
                      <span>DECRYPTING DATA STREAM...</span>
                   </div>
                 ) : (
                   <div className="whitespace-pre-wrap text-cyan-100/90 drop-shadow-[0_0_2px_rgba(6,182,212,0.5)]">
                      {streamedText}
                      <span className="inline-block w-2 h-4 bg-cyan-400 ml-1 animate-[flicker_0.1s_infinite]"></span>
                   </div>
                 )}
              </div>
              <div ref={textEndRef} />
           </div>

           {/* Action Bar */}
           <div className="p-6 border-t border-cyan-900/30 bg-black/40">
              <div className="flex items-center justify-between gap-4">
                 <div className="hidden md:flex flex-col">
                    <span className="text-[10px] text-cyan-800 uppercase tracking-widest">System Status</span>
                    <span className={`text-xs font-bold font-mono tracking-wider ${isReady ? 'text-green-400 animate-pulse' : 'text-yellow-600'}`}>
                       {isReady ? '>> READY TO EXECUTE <<' : '>> PROCESSING... <<'}
                    </span>
                 </div>

                 <button 
                    onClick={handleExecute}
                    disabled={!isReady && !quest.actionUrl}
                    className={`
                      relative group flex-1 md:flex-none md:w-72 py-4 border transition-all duration-300 overflow-hidden cursor-none
                      ${isReady 
                          ? 'bg-cyan-950/30 border-cyan-500 text-cyan-400 hover:bg-cyan-500 hover:text-black hover:shadow-[0_0_30px_rgba(6,182,212,0.6)]' 
                          : 'bg-black border-gray-800 text-gray-700 cursor-not-allowed'
                      }
                    `}
                 >
                    <div className="relative z-10 flex items-center justify-center gap-3 font-bold tracking-[0.2em] text-sm">
                       <span>INITIALIZE</span>
                       <ChevronRight className={`w-4 h-4 transition-transform duration-300 ${isReady ? 'group-hover:translate-x-2' : ''}`} />
                    </div>
                 </button>
              </div>
           </div>
        </div>

      </div>
    </div>
  );
};

export default SystemModal;