import { GoogleGenAI } from "@google/genai";

export const generateMissionBriefing = async (moduleName: string, moduleDesc: string): Promise<string> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    const prompt = `
      You are "Vibe", a hyper-advanced operating system AI.
      The user is initializing a system module: "${moduleName}".
      Context: ${moduleDesc}
      
      Generate a sleek, professional, and slightly futuristic "Initialization Log".
      Style: Scientific, precise, encouraging but cold/robotic. 
      Length: Max 40 words.
      Do not use markdown.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    return response.text || "SYSTEM_ERR: UNABLE_TO_GENERATE_LOG";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "OFFLINE: AI Core unreachable. Manual override required.";
  }
};