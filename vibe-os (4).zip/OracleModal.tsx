import React, { useEffect, useState } from 'react';
import { ModuleData } from './types';
import { X, ChevronRight } from 'lucide-react';
import { generateMissionBriefing } from './geminiService';

interface SystemModalProps {
  quest: ModuleData | null;
  onClose: () => void;
}

const SystemModal: React.FC<SystemModalProps> = ({ quest, onClose }) => {
  const [log, setLog] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [streamedText, setStreamedText] = useState('');
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    if (quest) {
      setLoading(true);
      setLog('');
      setStreamedText('');
      setIsReady(false);
      
      const descText = Array.isArray(quest.description) 
        ? quest.description.join('. ') 
        : quest.description;
      
      generateMissionBriefing(quest.title, descText).then((text) => {
        setLog(text);
        setLoading(false);
      });
    }
  }, [quest]);

  // Smooth text streaming
  useEffect(() => {
    if (!loading && log) {
      let i = 0;
      const speed = 20; 
      const interval = setInterval(() => {
        setStreamedText(log.slice(0, i + 1));
        i++;
        if (i > log.length) {
          clearInterval(interval);
          setIsReady(true);
        }
      }, speed);
      return () => clearInterval(interval);
    }
  }, [loading, log]);

  const handleExecute = () => {
    if (quest?.actionUrl) {
      window.open(quest.actionUrl, '_blank');
    }
    onClose();
  };

  if (!quest) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-black/60 backdrop-blur-md animate-unfold">
      <div className="relative w-full max-w-2xl bg-[#09090b]/95 border border-white/10 rounded-3xl shadow-2xl overflow-hidden flex flex-col md:flex-row ring-1 ring-white/10">
        
        {/* Left Side: Visual / Icon */}
        <div className="bg-gradient-to-br from-gray-900 to-black p-8 flex flex-col justify-center items-center w-full md:w-1/3 border-b md:border-b-0 md:border-r border-white/10 relative overflow-hidden shrink-0">
            <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20"></div>
            <div className="relative z-10 p-6 rounded-full bg-white/5 border border-white/10 shadow-[0_0_40px_rgba(255,255,255,0.05)]">
               <quest.icon className="w-12 h-12 text-white" />
            </div>
            <div className="mt-6 text-center">
                <h3 className="font-tech text-3xl font-bold text-white tracking-wider">{quest.title}</h3>
                <div className="mt-2 text-xs font-mono text-gray-500 bg-black/40 px-3 py-1 rounded-full border border-white/5 inline-block">
                    VER: 4.2.0
                </div>
            </div>
        </div>

        {/* Right Side: Content */}
        <div className="flex-1 p-8 flex flex-col relative">
           <button onClick={onClose} className="absolute top-4 right-4 text-gray-500 hover:text-white transition-colors z-20">
             <X className="w-5 h-5" />
           </button>

           <div className="flex-1">
              <div className="flex items-center gap-2 mb-6">
                 <div className={`w-2 h-2 rounded-full ${isReady ? 'bg-green-500' : 'bg-yellow-500'} animate-pulse`}></div>
                 <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">
                   {isReady ? 'System Ready' : 'Initializing...'}
                 </span>
              </div>

              <div className="font-mono text-sm leading-relaxed text-gray-300 min-h-[100px]">
                 {loading ? (
                    <div className="flex flex-col gap-2 opacity-50">
                       <div className="h-2 w-3/4 bg-gray-700 rounded animate-pulse"></div>
                       <div className="h-2 w-1/2 bg-gray-700 rounded animate-pulse delay-75"></div>
                       <div className="h-2 w-2/3 bg-gray-700 rounded animate-pulse delay-150"></div>
                    </div>
                 ) : (
                    <p>{streamedText}<span className="inline-block w-1.5 h-4 bg-white ml-1 align-middle animate-pulse"></span></p>
                 )}
              </div>
           </div>

           <div className="mt-8 pt-6 border-t border-white/5">
               <button 
                  onClick={handleExecute}
                  disabled={!isReady && !quest.actionUrl}
                  className={`
                    group w-full py-4 font-bold rounded-xl transition-all flex items-center justify-center gap-2
                    ${isReady 
                        ? 'bg-white text-black hover-pulse-glow hover:bg-gray-100 shadow-[0_0_15px_rgba(255,255,255,0.2)]' 
                        : 'bg-white/10 text-gray-500 cursor-wait'
                    }
                  `}
               >
                  <span className="tracking-wide">EXECUTE PROTOCOL</span>
                  <ChevronRight className={`w-4 h-4 transition-transform ${isReady ? 'group-hover:translate-x-1' : ''}`} />
               </button>
           </div>
        </div>

      </div>
    </div>
  );
};

export default SystemModal;