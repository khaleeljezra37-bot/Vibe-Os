import React, { useRef, useState } from 'react';
import { ModuleData } from './types';
import { ArrowUpRight } from 'lucide-react';

const THEME_STYLES = {
  cyan: {
    border: 'group-hover:border-cyan-400',
    text: 'text-cyan-400',
    bg: 'bg-cyan-950/30 group-hover:bg-cyan-900/40',
    shadow: 'shadow-[0_0_20px_-10px_rgba(6,182,212,0.3)] group-hover:shadow-[0_0_50px_0px_rgba(6,182,212,0.6)]',
    highlight: 'from-cyan-400/20 to-transparent',
    iconBg: 'group-hover:bg-cyan-400/20 group-hover:shadow-[0_0_20px_rgba(6,182,212,0.4)]'
  },
  violet: {
    border: 'group-hover:border-violet-400',
    text: 'text-violet-400',
    bg: 'bg-violet-950/30 group-hover:bg-violet-900/40',
    shadow: 'shadow-[0_0_20px_-10px_rgba(139,92,246,0.3)] group-hover:shadow-[0_0_50px_0px_rgba(139,92,246,0.6)]',
    highlight: 'from-violet-400/20 to-transparent',
    iconBg: 'group-hover:bg-violet-400/20 group-hover:shadow-[0_0_20px_rgba(139,92,246,0.4)]'
  },
  rose: {
    border: 'group-hover:border-rose-400',
    text: 'text-rose-400',
    bg: 'bg-rose-950/30 group-hover:bg-rose-900/40',
    shadow: 'shadow-[0_0_20px_-10px_rgba(244,63,94,0.3)] group-hover:shadow-[0_0_50px_0px_rgba(244,63,94,0.6)]',
    highlight: 'from-rose-400/20 to-transparent',
    iconBg: 'group-hover:bg-rose-400/20 group-hover:shadow-[0_0_20px_rgba(244,63,94,0.4)]'
  },
  amber: {
    border: 'group-hover:border-amber-400',
    text: 'text-amber-400',
    bg: 'bg-amber-950/30 group-hover:bg-amber-900/40',
    shadow: 'shadow-[0_0_20px_-10px_rgba(245,158,11,0.3)] group-hover:shadow-[0_0_50px_0px_rgba(245,158,11,0.6)]',
    highlight: 'from-amber-400/20 to-transparent',
    iconBg: 'group-hover:bg-amber-400/20 group-hover:shadow-[0_0_20px_rgba(245,158,11,0.4)]'
  }
};

const ModuleCard: React.FC<{ data: ModuleData; onSelect: (data: ModuleData) => void; index: number }> = ({ data, onSelect, index }) => {
  const theme = THEME_STYLES[data.colorTheme];
  const Icon = data.icon;
  const cardRef = useRef<HTMLDivElement>(null);
  
  const [rotation, setRotation] = useState({ x: 0, y: 0 });
  const [spotlight, setSpotlight] = useState({ x: 50, y: 50, opacity: 0 });
  const [isHovered, setIsHovered] = useState(false);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    
    const rect = cardRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;
    
    // 3D rotation calculation
    const rotateX = ((y - centerY) / centerY) * -8;
    const rotateY = ((x - centerX) / centerX) * 8;
    
    // Spotlight position as percentage
    const spotX = (x / rect.width) * 100;
    const spotY = (y / rect.height) * 100;

    setRotation({ x: rotateX, y: rotateY });
    setSpotlight({ x: spotX, y: spotY, opacity: 1 });
  };

  const handleMouseEnter = () => setIsHovered(true);

  const handleMouseLeave = () => {
    setIsHovered(false);
    setRotation({ x: 0, y: 0 });
    setSpotlight(prev => ({ ...prev, opacity: 0 }));
  };

  return (
    <div
      className="relative perspective-1000"
      style={{ 
        animation: `springUp 0.8s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards`,
        animationDelay: `${index * 100}ms`,
        opacity: 0,
        perspective: '1200px'
      }}
    >
      <div 
        ref={cardRef}
        onClick={() => onSelect(data)}
        onMouseMove={handleMouseMove}
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
        className={`
          relative h-full w-full rounded-2xl border border-white/5
          backdrop-blur-xl transition-all duration-300 ease-out
          cursor-pointer overflow-hidden group
          ${theme.bg} ${theme.border} ${theme.shadow}
        `}
        style={{
          transform: `rotateX(${rotation.x}deg) rotateY(${rotation.y}deg) scale3d(${isHovered ? 1.02 : 1}, ${isHovered ? 1.02 : 1}, 1)`,
          transformStyle: 'preserve-3d'
        }}
      >
        {/* Dynamic Spotlight Effect */}
        <div 
          className="pointer-events-none absolute inset-0 z-0 transition-opacity duration-300"
          style={{
            background: `radial-gradient(800px circle at ${spotlight.x}% ${spotlight.y}%, rgba(255,255,255,0.08) 0%, transparent 60%)`,
            opacity: spotlight.opacity
          }}
        />

        {/* Dynamic Highlight Gradient overlay based on mouse position (Sheen) */}
        <div 
          className={`pointer-events-none absolute inset-0 z-0 bg-gradient-to-br ${theme.highlight} opacity-0 group-hover:opacity-100 transition-opacity duration-500`}
          style={{
            transform: `translateZ(0px)`,
            maskImage: `radial-gradient(circle at ${spotlight.x}% ${spotlight.y}%, black 40%, transparent 100%)`
          }}
        />

        <div className="relative z-10 p-6 flex flex-col h-full justify-between transform-gpu" style={{ transform: 'translateZ(20px)' }}>
          
          {/* Header */}
          <div className="flex justify-between items-start mb-6">
            <div className={`
              p-3 rounded-xl bg-white/5 border border-white/10 ${theme.text} 
              transition-all duration-300 group-hover:scale-110 group-hover:rotate-3
              ${theme.iconBg}
            `}
            style={{ transform: 'translateZ(10px)' }}
            >
               <Icon className="w-6 h-6" />
            </div>
            
            <div 
              className="flex flex-col items-end"
              style={{ transform: 'translateZ(15px)' }}
            >
               <div className="flex items-center gap-1.5 px-2 py-1 rounded-full bg-black/40 border border-white/5 shadow-inner">
                  <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
                  </span>
                  <span className="text-[10px] font-bold text-gray-400 group-hover:text-green-400 transition-colors tracking-wider">ONLINE</span>
               </div>
            </div>
          </div>

          {/* Content */}
          <div className="mb-4">
            <h3 
              className="font-tech text-2xl font-bold text-white mb-2 tracking-wide group-hover:text-transparent group-hover:bg-clip-text group-hover:bg-gradient-to-r group-hover:from-white group-hover:to-gray-300 transition-all drop-shadow-md"
              style={{ transform: 'translateZ(30px)' }}
            >
              {data.title}
            </h3>
            <div 
              className="h-0.5 w-12 bg-white/10 mb-3 group-hover:w-full transition-all duration-700 ease-out group-hover:bg-white/30"
              style={{ transform: 'translateZ(25px)' }}
            />
            
            {Array.isArray(data.description) ? (
              <ul 
                className="text-gray-400 text-sm font-mono space-y-1.5 opacity-80 group-hover:text-gray-300 transition-colors"
                style={{ transform: 'translateZ(20px)' }}
              >
                {data.description.map((item, i) => (
                  <li 
                    key={i} 
                    className="flex items-start gap-2"
                    style={{ 
                      animation: 'text-slide-up 0.5s ease-out forwards',
                      animationDelay: `${0.3 + (i * 0.1)}s`, // Staggered effect
                      opacity: 0
                    }}
                  >
                    <span className={`text-[10px] mt-1 ${theme.text}`}>►</span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            ) : (
              <p 
                className="text-gray-400 text-sm font-mono whitespace-pre-line leading-relaxed opacity-80 group-hover:text-gray-300 transition-colors"
                style={{ transform: 'translateZ(20px)' }}
              >
                 <span 
                  className="block"
                  style={{ 
                    animation: 'text-slide-up 0.5s ease-out forwards',
                    animationDelay: '0.3s',
                    opacity: 0
                  }}
                 >
                   {data.description}
                 </span>
              </p>
            )}
          </div>

          {/* Stats Grid */}
          {data.stats.length > 0 && (
            <div 
              className="grid grid-cols-2 gap-2 mb-6"
              style={{ transform: 'translateZ(25px)' }}
            >
              {data.stats.map((stat, i) => (
                <div key={i} className="bg-black/30 rounded-lg p-2 border border-white/5 group-hover:border-white/10 transition-colors">
                    <div className="text-[10px] text-gray-500 uppercase tracking-wider">{stat.label}</div>
                    <div className="font-mono text-sm text-gray-200">{stat.value}</div>
                </div>
              ))}
            </div>
          )}

          {/* Footer Action */}
          <div 
            className="flex items-center justify-between mt-auto pt-4 border-t border-white/5"
            style={{ transform: 'translateZ(20px)' }}
          >
            <span className={`text-xs font-medium tracking-widest ${theme.text} opacity-0 group-hover:opacity-100 transition-all duration-300 translate-y-2 group-hover:translate-y-0 shadow-[0_0_10px_currentColor]`}>
               INITIALIZE
            </span>
            <ArrowUpRight 
              className={`w-4 h-4 text-gray-600 transition-all duration-300 group-hover:text-white group-hover:translate-x-1 group-hover:-translate-y-1`} 
            />
          </div>

        </div>
      </div>
    </div>
  );
};

export default ModuleCard;